// import { createSlice } from '@reduxjs/toolkit'

// const initialStateCommentaires = { id_user: '', id_post: '', content: '' }

// export const commentaireSlice = createSlice({
//     name: 'commentaires',
//     initialState: {
//         value: initialStateCommentaires,
//     },
//     reducers: {
//         ajouterCommentaire: (state, action) => {
//             state.value = action.payload
//         },
//     },
// })

// export const { ajouterCommentaire } = commentaireSlice.actions

// export default commentaireSlice.reducer
