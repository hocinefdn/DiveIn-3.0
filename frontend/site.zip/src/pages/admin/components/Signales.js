import React from 'react'

function Signales() {
    return <div>sisi</div>
}

export default Signales
