import React from 'react'
import '../css/discussion.css'
function Connecter() {
    return <div className="w-3 h-3 bg-green-400 rounded-lg connecter"></div>
}

export default Connecter
