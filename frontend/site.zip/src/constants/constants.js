// export const api = 'http://localhost:5000/'
// export const apiReact = 'http://localhost:3000/'

export const api = 'https://backend.divein-isi.com/'
export const apiReact = 'https://divein-isi.com/'
